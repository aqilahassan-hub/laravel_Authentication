<!DOCTYPE html>
<html>
<head>
    <title>Laravel 8 CRUD Application </title>
</head>
<body>
  
<div class="container">
    <?php echo $__env->yieldContent('content'); ?>
</div>
   
</body>
</html><?php /**PATH C:\xampp\htdocs\laravel\resources\views/profils/layout.blade.php ENDPATH**/ ?>