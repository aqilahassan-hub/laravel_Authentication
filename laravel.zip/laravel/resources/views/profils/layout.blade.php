<!DOCTYPE html>
<html>
<head>
    <title>Laravel 8 CRUD Application </title>
</head>
<body>
  
<div class="container">
    @yield('content')
</div>
   
</body>
</html>